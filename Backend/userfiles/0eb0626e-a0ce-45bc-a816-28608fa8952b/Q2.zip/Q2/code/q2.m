N=[5,10,20,40,60,80,100,500,1000,10000];

M=[]; Cx=[];
for i= N
    mle=[];
    pme=[];
    for k= [1:100]
        x=rand(i,1);
        y=-1/5*log(x);
        s=sum(y);
        ml=i/s;
        pm=(5.5+i)/(s+1);
        e1=abs(ml-5)/5;
        e2=abs(pm-5)/5;
        mle=[mle;e1];
        pme=[pme;e2];
    end
    M=[M,mle];
    Cx=[Cx,pme];
end

figure(1);
boxplot(M,N,'Colors','r');
hold on;
boxplot(Cx,N,'Colors','g');
title('Error in MLE estimate (in Red), and PME estimate (in Green)')
xlabel('N')
ylabel('Error in estimate (M=100)')