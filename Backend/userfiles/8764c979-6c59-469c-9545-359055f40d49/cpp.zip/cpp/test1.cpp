#include <iostream>
#include<vector>
#include <algorithm>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a;
    vector < int >  v;
    vector<int> ans(n, 0);
    for (int i=0; i < n; i++)
    {
        cin >> a;
        v.push_back(a);
    }
    int d = 0;
    sort(v.begin(), v.end());
    for (int i = 1; i < n; i+=2)
    {
        ans[i] = v[(i - 1) / 2];
        d++;
    }
    for (int j = 0; j < n; j+=2)
    {
        ans[j] = v[d];
        d++;
    }
    if (n % 2 == 0) cout << n / 2 - 1<<endl;
    else cout << n / 2<<endl;
    for (int i=0; i < n; i++)
    {
        cout << ans[i]<<" ";
    }
    return 0;
}