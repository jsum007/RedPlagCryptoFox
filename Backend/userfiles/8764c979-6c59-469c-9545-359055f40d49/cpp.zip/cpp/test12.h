#include<iostream>
#include<cmath>
using namespace std;

class quad_tree{
	
	int val;
	int h;

	quad_tree * topleft;
	quad_tree * topright;
	quad_tree * bottomleft;
	quad_tree * bottomright;

	//for the resize operation when m < height, gives the sum of all submatrix values for the root
	long long int avg(){
		if(this->topleft == NULL){
			long long int ans = this->val*pow(4,this->h);
			return ans;
		}
		else{
			long long int ans = this->topleft->avg();
			ans += this->topright->avg();
			ans += this->bottomleft->avg();
			ans += this->bottomright->avg();

			return ans;
		}
	}

public:
	quad_tree(int n){
		
		h = n;
		val = 0;

		topleft = NULL;
		topright = NULL;
		bottomleft = NULL;
		bottomright = NULL;

	}

	quad_tree(quad_tree const &Q){
		this->h = Q.h;
		this->val = Q.val;
		// cout<<"mk8"<<endl;
		if(Q.topleft == NULL){
			// cout<<"mk9"<<endl;
			this->topleft = NULL;
			this->topright = NULL;
			this->bottomleft = NULL;
			this->bottomright = NULL;
		}
		else{
			// cout<<"here"<<endl;
			this->topleft = new quad_tree(*(Q.topleft));
			this->topright = new quad_tree(*(Q.topright));
			this->bottomleft = new quad_tree(*(Q.bottomleft));
			this->bottomright = new quad_tree(*(Q.bottomright));
		}
	}

	~quad_tree(){

		delete topleft;
		delete topright;
		delete bottomleft;
		delete bottomright;

	}

	int size(){
		return h;
	}

	int get(int x, int y){
		if(topleft!=NULL){
			int power = pow(2,h-1);
			if(x < power){
				if(y < power){
					return topleft->get(x,y);
				}
				else{
					return bottomleft->get(x,y-power);
				}
			}
			else{
				if(y < power){
					return topright->get(x-power,y);
				}
				else{
					return bottomright->get(x-power,y-power);
				}
			}
		}
		else
			return val;
	}

	void set(int x1, int y1, int x2, int y2, int b){
		//check if size 0, only when set called for inappropriate quadrant
		if(x2 < x1 || y2 < y1)
			return;
		//used multiple times
		float powerf = pow(2,h-1);
		int poweri = pow(2,h-1);
		//when coordinates cover the whole quadrant
		if(x2 - x1 == int(2*powerf-1) && y2 - y1 == int(2*powerf-1)){

			delete this->topleft;
			delete this->topright;
			delete this->bottomleft;
			delete this->bottomright;

			this->topleft = NULL;
			this->topright = NULL;
			this->bottomleft = NULL;
			this->bottomright = NULL;

			this->val = b;
		}
		//if not covering whole quadrant, call set for all quadrants
		else{
			//if this was a leaf node
			if(this->topleft == NULL){

				// cout<<"mk1"<<endl;
				
				this->topleft = new quad_tree(h-1);
				this->topright = new quad_tree(h-1);
				this->bottomleft = new quad_tree(h-1);
				this->bottomright = new quad_tree(h-1);

				// cout<<"mk2"<<endl;
				
				this->topleft->set(0,0,poweri-1,poweri-1,val);
				this->topright->set(0,0,poweri-1,poweri-1,val);
				this->bottomleft->set(0,0,poweri-1,poweri-1,val);
				this->bottomright->set(0,0,poweri-1,poweri-1,val);
				
				// cout<<"mk3"<<endl;
			}
			//will call functions for all, but for where its inappropriate, (x2 < x1 || y2 < y1)
			this->topleft->set(min(poweri,x1),min(poweri,y1),min(poweri-1,x2),min(poweri-1,y2),b);
			this->bottomleft->set(min(poweri,x1),max(y1 - poweri,0),min(poweri-1,x2),max(y2 - poweri,-1),b);
			this->topright->set(max(x1 - poweri,0),min(poweri,y1),max(x2 - poweri,-1),min(poweri-1,y2),b);
			this->bottomright->set(max(x1 - poweri,0),max(y1 - poweri,0),max(x2 - poweri,-1),max(y2 - poweri,-1),b);

			// when all subtrees end up with same values, they need to be deleted and root tree assigned the value same as the subtrees
			// the subtrees are also assigned NULL values after deleting to fit conditions in other functions
			if(topleft->topleft == NULL && topright->topleft == NULL && bottomleft->topleft == NULL && bottomright->topleft == NULL){
				if(topleft->val == bottomleft->val && topright->val == bottomright->val && topleft->val == topright->val){

					this->val = this->topleft->val;
					
					delete this->topleft;
					delete this->topright;
					delete this->bottomleft;
					delete this->bottomright;

					// cout<<"mk3"<<endl;
					this->topleft = NULL;
					this->topright = NULL;
					this->bottomleft = NULL;
					this->bottomright = NULL;
					// cout<<"mk4"<<endl;
				}
			}


		}
	}

	void complement(){
		//complement the values if a single block
		int v = this->val;
		v = ~v&1;
		this->val = v;

		if(this->topleft == NULL)
			return;
		else{
			this->topleft->complement();
			this->topright->complement();
			this->bottomleft->complement();
			this->bottomright->complement();
		}
	}

	void overlap(quad_tree const &Q){
		//when both have subtrees
		if(this->topleft != NULL && Q.topleft != NULL){
			// cout<<"both non-null"<<endl;
			this->topleft->overlap(*(Q.topleft));
			// cout<<"w"<<endl;
			this->topright->overlap(*(Q.topright));
			// cout<<"x"<<endl;
			this->bottomleft->overlap(*(Q.bottomleft));
			// cout<<"y"<<endl;
			this->bottomright->overlap(*(Q.bottomright));
			// cout<<"z"<<endl;
		}
		//when only base tree has subtrees
		else if(this->topleft != NULL && Q.topleft == NULL){
			// cout<<"a non-null b null"<<endl;
			this->topleft->overlap(Q);
			this->topright->overlap(Q);
			this->bottomleft->overlap(Q);
			this->bottomright->overlap(Q);
		}
		//when base tree doesn't have subtrees, but the 2nd tree has, create new subtrees with same values by copying the root tree to subtrees, and reducing their height by one
		else if(this->topleft == NULL && Q.topleft != NULL){
			// cout<<"a null b non-null"<<endl;
			quad_tree node(*this);
			node.h--;
			this->topleft = new quad_tree(node);
			this->topright = new quad_tree(node);
			this->bottomleft = new quad_tree(node);
			this->bottomright = new quad_tree(node);
			// cout<<"mk5"<<endl;

			this->topleft->overlap(*(Q.topleft));
			this->topright->overlap(*(Q.topright));
			this->bottomleft->overlap(*(Q.bottomleft));
			this->bottomright->overlap(*(Q.bottomright));
			// cout<<"mk6"<<endl;
		}
		// when both don't have subtrees
		else{
			// cout<<"both null"<<endl;
			
			this->val = (this->val)|(Q.val);
			// cout<<this->val<<" done"<<endl;
		}
		// when all subtrees end up with same values, they need to be deleted and root tree assigned the value same as the subtrees
		// the subtrees are also assigned NULL values after deleting to fit conditions in other functions
		if(this->topleft != NULL){

			if(topleft->topleft == NULL && topright->topleft == NULL && bottomleft->topleft == NULL && bottomright->topleft == NULL){
				if(topleft->val == bottomleft->val && topright->val == bottomright->val && topleft->val == topright->val){

					this->val = this->topleft->val;

					delete this->topleft;
					delete this->topright;
					delete this->bottomleft;
					delete this->bottomright;

					// cout<<"mk3"<<endl;
					this->topleft = NULL;
					this->topright = NULL;
					this->bottomleft = NULL;
					this->bottomright = NULL;
					// cout<<"mk4"<<endl;
				}
			}
		}
	}

	void intersect(quad_tree &Q){
		//when both have subtrees
		// cout<<"intersection"<<endl;
		if(this->topleft != NULL && Q.topleft != NULL){
			// cout<<"both non-null"<<endl;
			this->topleft->intersect(*(Q.topleft));
			// cout<<"w"<<endl;
			this->topright->intersect(*(Q.topright));
			// cout<<"x"<<endl;
			this->bottomleft->intersect(*(Q.bottomleft));
			// cout<<"y"<<endl;
			this->bottomright->intersect(*(Q.bottomright));
			// cout<<"z"<<endl;
		}
		//when only base tree has subtrees
		else if(this->topleft != NULL && Q.topleft == NULL){
			// cout<<"a non-null b null"<<endl;
			this->topleft->intersect(Q);
			this->topright->intersect(Q);
			this->bottomleft->intersect(Q);
			this->bottomright->intersect(Q);
		}
		//when base tree doesn't have subtrees, but the 2nd tree has, create new subtrees with same values by copying the root tree to subtrees, and reducing their height by one
		else if(this->topleft == NULL && Q.topleft != NULL){
			// cout<<"a null b non-null"<<endl;
			quad_tree node(*this);
			node.h--;
			this->topleft = new quad_tree(node);
			this->topright = new quad_tree(node);
			this->bottomleft = new quad_tree(node);
			this->bottomright = new quad_tree(node);
			// cout<<"mk5"<<endl;

			this->topleft->intersect(*(Q.topleft));
			this->topright->intersect(*(Q.topright));
			this->bottomleft->intersect(*(Q.bottomleft));
			this->bottomright->intersect(*(Q.bottomright));
			// cout<<"mk6"<<endl;
		}
		// when both don't have subtrees
		else{
			// cout<<"both null"<<endl;
			
			this->val = (this->val)&(Q.val);
			// cout<<(this->val) + 1<<" done"<<endl;
		}
		// when all subtrees end up with same values, they need to be deleted and root tree assigned the value same as the subtrees
		// the subtrees are also assigned NULL values after deleting to fit conditions in other functions
		if(this->topleft != NULL){

			if(topleft->topleft == NULL && topright->topleft == NULL && bottomleft->topleft == NULL && bottomright->topleft == NULL){
				if(topleft->val == bottomleft->val && topright->val == bottomright->val && topleft->val == topright->val){

					this->val = this->topleft->val;
					
					delete this->topleft;
					delete this->topright;
					delete this->bottomleft;
					delete this->bottomright;

					// cout<<"mk3"<<endl;
					this->topleft = NULL;
					this->topright = NULL;
					this->bottomleft = NULL;
					this->bottomright = NULL;
					// cout<<"mk4"<<endl;
				}
			}
		}
	}

	void resize(int m){
		// cout<<"height : "<<this->h<<" m : "<<m<<endl;
		if(this->h == m){
			return;
		}
		else if(this->h < m){
			if(this->topleft != NULL){
				// cout<<this->h<<endl;
				this->topleft->resize(m-1);
				this->topright->resize(m-1);
				this->bottomleft->resize(m-1);
				this->bottomright->resize(m-1);
				// cout<<this->h<<endl;
			}
			// cout<<"here"<<endl;
			this->h = m;
		}
		else if(this->h > m){
			if(m>0){
				if(this->topleft != NULL){
					this->topleft->resize(m-1);
					this->topright->resize(m-1);
					this->bottomleft->resize(m-1);
					this->bottomright->resize(m-1);
				}
			}
			else{
				if(this->topleft != NULL){
					// the values will never be all 1 here, so can assign as:
					// avg >= #half cells -> val = 1, else val = 0
					this->val = 2*this->avg()/pow(4,h);

					this->topleft = NULL;
					this->topright = NULL;
					this->bottomleft = NULL;
					this->bottomright = NULL;
				}
			}
			this->h = m;
		}
	}

	void extract(int x, int y, int m){
		if(m == this->h)
			return;
		// copy the root tree for reference
		quad_tree *tree = new quad_tree(*this);
		int power = pow(2,m);
		int diff = pow(2,(this->h)-m);
		// get the values of the root tree from the submatrix and "project" them on the root tree
		for(int i = 0;i<power;i++){
			for(int j = 0;j<power;j++){
				this->set(diff*i,diff*j,(i+1)*diff-1,(j+1)*diff-1,tree->get(x+i,y+j));
			}
		}
		this->resize(m);
	}

};