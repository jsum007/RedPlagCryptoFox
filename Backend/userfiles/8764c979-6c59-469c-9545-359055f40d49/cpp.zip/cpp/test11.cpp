#include<iostream>
#include<vector>
using std::cout;
using std::cin;
using std::endl;
using std::vector;

long long int rank(vector<int> seq){
	int n = seq.size();
	int comps[n][n];
	// cout<<"creating matrix"<<endl;
	for(int i = 0;i<n;i++){
		comps[0][i] = 1;
	}
	// cout<<"still creating matrix"<<endl;
	for(int i = 1;i<n;i++){
		for(int j = 0;j<n-i;j++){
			comps[i][j] = comps[i-1][j+1] + (j+1)*comps[i-1][j];
		}
	}

	for(int i = 0;i<n;i++){
		for(int j = 0;j<n-i;j++){
			cout<<comps[i][j]<<" ";
		}
		cout<<endl;
	}

	// cout<<"calculating rank"<<endl;
	long long int count = 0;
	int val,max = 0;

	for(int i = 1;i<n;i++){
		val = seq[i];
		for(int j = 0;j<val;j++){
			cout<<i<<" "<<j<<endl;
			count += comps[n-i-1][j];
		}
	}
	count++;
	// cout<<"done"<<endl;

	return count;
}

		// max = *max_element(vect.begin(),vect.begin()+i);



vector<int> seq(long long int rank, int n){

}

void output(vector<vector<int>> queries, int n, int t, char types[]){

	long long int count = 0;
	int val,max = 0;
	int comps[n][n];
	vector<int> query;
	vector<int> seq;
	// cout<<"creating matrix"<<endl;
	for(int i = 0;i<n;i++){
		comps[0][i] = 1;
	}
	// cout<<"still creating matrix"<<endl;
	for(int i = 1;i<n;i++){
		for(int j = 0;j<n-i;j++){
			comps[i][j] = comps[i-1][j+1] + (j+1)*comps[i-1][j];
		}
	}

	// for(int i = 0;i<n;i++){
	// 	for(int j = 0;j<n-i;j++){
	// 		cout<<comps[i][j]<<" ";
	// 	}
	// 	cout<<endl;
	// }

	for(int k = 0;k<t;k++){
		// cout<<"in loop"<<endl;
		query = queries[k];
		if(types[k] == 'R'){
			count = 0;
			val,max = 0;

			for(int i = 1;i<n;i++){
				// cout<<"fine"<<endl;
				val = query[i];
				// cout<<val<<" ";
				for(int j = 0;j<val;j++){
					// cout<<i<<" "<<j<<endl;
					count += comps[n-i-1][j];
				}
			}
			// cout<<"count"<<endl;
			count++;
			cout<<count<<endl;
			// queries.erase(queries.begin());

		}
		else if(types[k] == 'U'){
			count = query[0];
			seq.push_back(0);
			max = 0;

			for(int i = 1;i<n;i++){
				// cout<<"fine"<<endl;
				val = query[i];
				// cout<<val<<" ";
				for(int j = 0;j<val;j++){
					// cout<<i<<" "<<j<<endl;
					count += comps[n-i-1][j];
				}
			}
			cout<<"count"<<endl;
			count++;

			for(int i = 1;i<n;i++){
				for(int j = 0;j<max+1;j++){
					if(comps[n-i-1][max]<=count){
						count -= comps[n-i-1][max];
						if(j==max)
							max++;
						cout<<"if1"<<endl;
						break;
					}
					else if(comps[n-i-1][max]>count){
						if(j == 0){
							seq.push_back(j);
							cout<<"if2"<<endl;
							break;
						}
						else if(j>0){
							count -= comps[n-i-1][max];
							seq.push_back(j-1);
							cout<<"if"<<endl;
							break;
						}
					}
					

				}
			}

			for(int a : seq){
				cout<<a<<" ";
			}
			cout<<endl;
		}
	}

}

int main(){

	int n,t;
	cin>>n>>t;
	vector<vector<int>> queries;
	vector<int> que;
	char type;
	char types[t];
	int value;
	// cout<<"queries created"<<endl;

	for(int i = 0;i<t;i++){
		cin>>type;
		types[i] = type;
		if(type == 'R'){
			// cout<<type<<endl;
			for(int j = 0; j<n; j++){
				// cout<<i<<" "<<j<<endl;
				cin>>value;
				// cout<<"input taken"<<endl;
				que.push_back(value);
				// cout<<"pushed"<<endl;
			}
			queries.push_back(que);
			que.clear();
		}
		else if(type == 'U'){
			cin>>value;
			que.push_back(value);
			queries.push_back(que);
			que.clear();
		}
	}
	// cout<<"input complete"<<endl;

	// for(int i = 0;i<t;i++){
	// 	if(queries[i].size() > 1){
	// 		cout<<rank(queries[i])<<endl;
	// 		cout<<"rank done"<<endl;
	// 	}
	// 	// if(que[i].size() == 1){
	// 	// 	vector<int> result = seq(que[i]);
	// 	// 	for(int j = 0;j<result.size();j++){
	// 	// 		cout<<result[j]<<" ";
	// 	// 	}
	// 	// }
	// }
	// cout<<"rank loop done"<<endl;

	output(queries,n,t,types);


}