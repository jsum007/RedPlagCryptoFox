#include<iostream>
#include<string>
#include<vector>
#include<list>
#include<map>
#include<algorithm>
using namespace std;
// ios_base::sync_with_stdio(false);
//     cin.tie(0);
//     cout.tie(0);

struct crs{
	int slot;
	int maxregs;
	int regs = 0;
	vector<string> students;
};

struct operation{
	char name;
	string param;
};

struct student{
	vector<int> slots;
	vector<string> courses;
};

vector<string> rollnos;
vector<string> courses;
map<string,crs> course_det;
vector<operation> ops;
map<string,student> rollno_det;
 
void operate(int maxco){
	for(auto& op : ops){
		if(op.name=='R'){
			string roll(op.param,1,9);
			string cour(op.param,11,6);
			

			if(find(rollnos.begin(),rollnos.end(),roll)==rollnos.end()||find(courses.begin(),courses.end(),cour)==courses.end()){
				cout<<"fail\n";
				// cout<<"mark1"<<endl;
				continue;
			}
			if(rollno_det[roll].courses.size()==maxco||course_det[cour].students.size()==course_det[cour].maxregs){
				cout<<"fail\n";
				// cout<<"mark2"<<endl;
				continue;
			}

			if(find(course_det[cour].students.begin(),course_det[cour].students.end(),roll)==course_det[cour].students.end() && (rollno_det[roll].slots.empty()||(find(rollno_det[roll].slots.begin(),rollno_det[roll].slots.end(),course_det[cour].slot)==rollno_det[roll].slots.end()))){
				rollno_det[roll].courses.push_back(cour);
				rollno_det[roll].slots.push_back(course_det[cour].slot);
				course_det[cour].students.push_back(roll);

				cout<<"success\n";
				continue;
			}
			else cout<<"fail\n";
			// cout<<"mark4"<<endl;
			continue;
		}

		else if(op.name=='D'){
			string roll(op.param,1,9);
			string cour(op.param,11,6);

			auto it = find(course_det[cour].students.begin(),course_det[cour].students.end(),roll);
			if(it!=course_det[cour].students.end()){
				course_det[cour].students.erase(it);
				it = find(rollno_det[roll].courses.begin(),rollno_det[roll].courses.end(),cour);
				rollno_det[roll].courses.erase(it);
				cout<<"success\n";
				continue;
			}
			cout<<"fail\n";
			// cout<<"mark3"<<endl;
			continue;
		}	

		else if(op.name=='P'){
			// cout<<"P"<<endl;
			if(op.param.size()==10){
				string roll(op.param,1,9);

				for(auto& cour:rollno_det[roll].courses)
					cout<<cour<<" ";
				cout<<endl;
				continue;
			}

			else if(op.param.size()==7){

				string cour(op.param,1,6);
				for(auto& stud:course_det[cour].students)
					cout<<stud<<" ";
				cout<<endl;
				continue;
			}

			else if(op.param.size()==20){
				
				string roll1(op.param,1,9);
				string roll2(op.param,11,9);
				// cout<<roll1<<"here "<<roll2<<endl;

				vector<string> common(rollno_det[roll1].courses.size()+rollno_det[roll2].courses.size());
				vector<string>:: iterator it;

				sort(rollno_det[roll1].courses.begin(),rollno_det[roll1].courses.end());
				sort(rollno_det[roll2].courses.begin(),rollno_det[roll2].courses.end());

				it = set_intersection(rollno_det[roll1].courses.begin(),rollno_det[roll1].courses.end(),rollno_det[roll2].courses.begin(),rollno_det[roll2].courses.end(),common.begin());
				common.shrink_to_fit();

				for(it = common.begin();it!=common.end();it++)
					cout<<*it<<" ";
				cout<<endl;
				continue;
			}

			else if(op.param.size()==14){

				string cour1(op.param,1,6);
				string cour2(op.param,8,6);

				vector<string> common(course_det[cour1].students.size()+course_det[cour2].students.size());
				vector<string>:: iterator it;

				sort(course_det[cour1].students.begin(),course_det[cour1].students.end());
				sort(course_det[cour2].students.begin(),course_det[cour2].students.end());

				it = set_intersection(course_det[cour1].students.begin(),course_det[cour1].students.end(),course_det[cour2].students.begin(),course_det[cour2].students.end(),common.begin());
				common.shrink_to_fit();

				for(it = common.begin();it!=common.end();++it)
					cout<<*it<<" ";
				cout<<endl;
				continue;
			}
		}

	}
}

int main(){
	ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

	int numco,numst,maxco,numops;
	cin>>numco>>numst>>maxco>>numops;

	string course_name;
	crs course;
	string rollno;
	operation op;
	int slot;

	for(int i = 0;i<numco;i++){
		cin>>course_name>>course.slot>>course.maxregs;
		courses.push_back(course_name);
		course_det.insert({course_name,course});
	}

	for(int i = 0;i<numst;i++){
		cin>>rollno;
		rollnos.push_back(rollno);
	}

	for(int i = 0;i<numops;i++){
		cin>>op.name;
		getline(cin,op.param);
		ops.push_back(op);
	}

	operate(maxco);

}