// path() and dijkstra() functions partly taken from 
// https://www.geeksforgeeks.org/check-graphs-cycle-odd-length/
// https://www.geeksforgeeks.org/shortest-path-with-even-number-of-edges-from-source-to-destination/

#include<iostream>
#include<string>
#include<list>
#include<vector>
#include<algorithm>
#include<queue>
#include<utility>
#include<fstream>
using namespace std;

const int MAXX1 = 100000, MAXX2 = 200000, INF = 1e9;
vector<vector<int>> gr(MAXX1 + 3);

bool path(int n){

	int color[n];
	color[0] = 1;
	for (int i = 1; i < n; ++i){
		color[i] = -1;
	}

	queue<int> q;
	q.push(0);

	while (!q.empty()){

	    int u = q.front();
	    q.pop();
	    // cout<<u<<" : "<<endl;

	    vector<int>::iterator it = gr[u].begin();
	    while(it != gr[u].end()){
	        // cout<<*it<<endl;
	        if (color[*it] == -1){
	            color[*it] = 1 - color[u];
	            q.push(*it);
	        }
	        else if (color[u] == color[*it]){
	        	// cout<<u<<" "<<*it<<endl;
	            cout<<"possible"<<endl;
	            return true;
	        }
	        it++;
	    }
	}
	cout<<"impossible"<<endl;
	return false;

}

vector<vector<int>> adj(MAXX2 + 3);
vector<int> dist1(MAXX2 + 3, INF);
vector<int> dist2(MAXX1 + 3, INF);
vector<int> dist3(MAXX1 + 3, INF);

int even(int x){ 
    return x * 2;
}

int odd(int x){ 
    return x * 2 + 1; 
}

void dijkstra(int src,int dest,int n){
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq1; 

    pq1.push({0,even(src)});
    dist1[even(src)] = 0; 
  
    while (!pq1.empty()){
        int u1 = pq1.top().second;
        pq1.pop();

        for (int v1 : adj[u1]){

            if (dist1[u1] + 1 < dist1[v1]){
                dist1[v1] = dist1[u1] + 1;
                pq1.push({ dist1[v1], v1 });
            }
        }
    }
    int ans = dist1[even(dest)]/2;
    cout<<ans<<endl;

	priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq2;

    pq2.push({0,even(dest)}); 
    dist2[even(dest)] = 0; 
  
    while (!pq2.empty()){
        int u2 = pq2.top().second; 
        pq2.pop(); 

        for (int v2 : adj[u2]){

            if (dist2[u2] + 1 < dist2[v2]){
                dist2[v2] = dist2[u2] + 1;
                pq2.push({ dist2[v2], v2 });
            }
        }
    }

    vector<int> nodes;
    if(ans%2 == 0){
	    for(int i = 0;i<n;i++){
	    	if(dist1[even(i)] == ans && dist2[even(i)] == ans){
	    		nodes.push_back(i);
		    }
		}
	}
	else{
	    for(int i = 0;i<n;i++){
	    	if(dist1[odd(i)] == ans && dist2[odd(i)] == ans){
	    		nodes.push_back(i);
		    }
		}
    }
    sort(nodes.begin(), nodes.end());
    for(int i : nodes)
    	cout<<i<<" ";
    cout<<endl;
    cout<<dist1[even(48716)]<<endl;
	cout<<dist2[even(48716)]<<endl;    

}

int main(){

	ifstream in("in1.txt");
	int n,m,u,v;
	in>>n>>m>>u>>v;
	// list<int> gr[n];
	int a,b;
	for(int i = 0;i<m;i++){
		in>>a>>b;
		gr[a].push_back(b);
		gr[b].push_back(a);

		adj[even(a)].push_back(odd(b)); 
		adj[odd(a)].push_back(even(b)); 
		adj[odd(b)].push_back(even(a)); 
		adj[even(b)].push_back(odd(a));
	}

	if(gr[u].size() == 0 || gr[v].size() == 0)
		cout<<"impossible"<<endl;
	else{
		vector<int>::iterator it = gr[u].begin();
		while(it != gr[u].end()){
			if(*it == v)
				break;
			it++;
		}
		if(it == gr[u].end()){
			// cout<<"in"<<endl;
			gr[u].push_back(v);
			gr[v].push_back(u);
		}
		bool ct = path(n);
		if(ct){
			dijkstra(u,v,n);
		}
		cout<<"done"<<endl;

		return 0;

	}
}