#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

class perm{
	int arr_len;
	vector<int> array;
public:
	

			perm(){};

	perm(int n,int a[]){
	
		arr_len = n;
		for(int i=0;i<n;i++){
			array.push_back(a[i]);
		}
	}
	~perm(){};
	
	perm(perm const &q){
		
		arr_len = q.arr_len;
		array = q.array;
	}

	int size() const{
		return arr_len;
	}

	perm const operator=(perm const &q){
 		
 		perm temp;
		temp.arr_len = q.arr_len;
		temp.array = q.array;
		return temp;

	}


	perm const operator*(perm const &q) const{

		perm comp;
		comp.arr_len = this->size();



		for(int i = 		0;i<arr_len;i++){
						comp.array.push_back(this->array[this->array[i]]);
		}
		return comp;
	}

	int* to_array() const{
		int *p;
		p = new int[arr_len];
		for(int i = 0;i<arr_len;i++){
			p[i] = array[i];
		}
		return p;
	}


	perm const operator^(long long int i) const{

		perm p(*this);
		perm s(*this);

		for(int i = 0;i<p.size();i++)
			p = p*s;
		return p;

	}	

	bool const operator==(perm const &q) const{

		perm rhs(q);
		perm lhs(*this);
		return(lhs.array == rhs.array);

	}

	bool is_power(perm const &q) const{
		
		bool value = true;
		
		perm p(*this);
		perm s(q);
		perm r(q);
		while(true){
			if(p == s)
				break;
			else{
				s = s*r;
				if(s == r){
					value = false;
					break;
				}

			}

		}

		return value;
	}	


	int log(perm const &q) const{int value = 0;long long int count = 0;perm p(*this);perm s(q);perm r(q);while(true){value = value%(1000000007) + 1;// count++;
			if(p == s){break;}else{s = s*r;if(s == r){value = 0;break;
				}

			}

		}

		return value;

	}

};
