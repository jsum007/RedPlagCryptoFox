#include<iostream>
#include<vector>
#include<list>
#include<queue>
#include<stack>
#include<set>
using namespace std;

vector<list<int>> ad1(100003);
vector<list<int>> ad2(100003);
bool visf[100003] = {};
bool visb[100003] = {};
vector<vector<int>> comps;
vector<int> comp;
stack<int> fin;
int func[100003];
vector<int> pre;
vector<int> post;

void part0(int n){
	int siz = 0;

	vector<list<int>> rev(n);
	for(int i = 0;i<n;i++){
		for(int v : ad1[i]){
			rev[v].push_back(i);
		}
	}

	set<pair<int,int>> ans;
	queue<int> q;
	visf[0] = true;
	q.push(0);

	while(!q.empty()){
		int u = q.front();
		q.pop();
		for(int v : ad1[u]){
			if(!visf[v]){
				siz++;
				visf[v] = true;
				q.push(v);
				ans.insert(make_pair(u,v));
			}
		}
	}

	visb[0] = true;
	q.push(0);

	while(!q.empty()){
		int u = q.front();
		q.pop();
		for(int v : rev[u]){
			if(!visb[v]){
				siz++;
				visb[v] = true;
				q.push(v);
				ans.insert(make_pair(v,u));
			}
		}
	}

	cout<<siz<<endl;
	for(auto edge : ans){
		cout<<edge.first<<" "<<edge.second<<endl;
	}
}

void make_stack(int u){

	visf[u] = true;
	for(int v : ad1[u]){
		if(!visf[v]){
			visf[v] = true;
			make_stack(v);
		}
	}
	fin.push(u);
}

void get_comps(int u){

	visb[u] = true;
	comp.push_back(u);
	func[u] = *(comp.begin());
	for(int v : ad2[u]){
		if(!visb[v]){
			visb[v] = true;
			get_comps(v);
		}
	}
}

void part3(int n){

	make_stack(0);
	for(int u = 0;u<n;u++){
		for(int v : ad1[u]){
			ad2[v].push_back(u);
		}
	}
	while(!fin.empty()){
		int u = fin.top();
		fin.pop();
		if(!visb[u]){
			get_comps(u);
			comps.push_back(comp);
			comp.clear();
		}
	}

	vector<list<int>>ad3(n);
	for(int u = 0;u<n;u++){
		for(int v : ad1[u]){
			ad3[func[u]].push_back(func[v]);
		}
	}

	bool in[n] = {};
	bool out[n] = {};

	for(int u = 0;u<n;u++){
		for(int v : ad3[u]){
			if(u!=v){
				out[u] = true;
				in[v] = true;
			}
		}
	}
	int totin = 0;
	int totout = 0;
	int compnum = 0;
	for(int i = 0;i<n;i++){
		if(!ad3[i].empty()){
			compnum++;
			if(!out[i])
				totout++;
			if(!in[i])
				totin++;
		}
	}
	int wt = 0;
	if(compnum == 1)
		wt++;
	cout<<max(totin,totout)-wt<<endl;

}

int main(){
	int n,e,op;
	cin>>n>>e>>op;
	int a,b;

	for(int i = 0;i<e;i++){
		cin>>a>>b;
		ad1[a].push_back(b);
	}

	switch(op){

		case 0:
		part0(n);
		break;

		case 1:
		break;
		
		case 2:
		break;
		
		case 3:
		part3(n);
		break;
	}
}