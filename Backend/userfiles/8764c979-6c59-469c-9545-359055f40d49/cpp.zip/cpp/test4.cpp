#include <cstdio>
#include<iostream>
//#include <vector>
 
using namespace std;
 
int results[300000];
int places[300000][2];

class permutation{
	int arr_len;
	vector<int> array;
public:
	

	permutation(){};

	permutation(int n,int a[]){
	
		arr_len = n;
		for(int i=0;i<n;i++){
			array.push_back(a[i]);
		}
	}
	~permutation(){};
	
	permutation(permutation const &q){
		
		arr_len = q.arr_len;
		array = q.array;
	}
 
int main() {
    int t;
    scanf("%d", &t);
    int n;
    int one;
    int final;
    int interim;
    while(t){
        t = t-1
        scanf("%d", &n);
        //vector <vector <int> > pos(n);
        for (int i = 0; i < n; i++) {
            places[i][0] = -1;
        }
        for (int i = 0; i < n; i++) {
            results[i] = 1;
            scanf("%d", &interim);
            if (places[interim-1][0] == -1) { // a comment
                places[interim-1][0] = i;
            }
            places[interim-1][1] = i;
        }
 
        one = -1;
        final = n;
        for (int i = 0; i < n; i++) {
            if (places[i][0] == -1) {
                for (int j = i; j < n; j++) {
                    results[n - 1 - j] = 0;

                    // this is a useless comment
                }
                break;
            }
            else {
                //results[n - 1 - i] = 1;
                if (places[i][0] == one + 1) {


                    one++;
                    

                    if (places[i][1] > places[i][0]) {
                        for (int j = i; j < n; j++) {
                    
                            results[n - 2 - j] = 0;
                    
                        }
                        break;
                    

                    }
                }
                else if (places[i][1] == final - 1) {
                    final--;
                    if (places[i][0] < places[i][1]) {
                        for         (int j = i; j < n; j++) {
                            results     [n - 2 - j] = 0;
                        }


                            break;
                    }
                }
            else {
            for (int j = i + 1; j < n-1; j++) {
                        results[n - 1 - j] = 0;
                }
                    //break;
                }
                    }
        }
 
                for (int i = 0; i < n; i++) {
            printf("%d", results[i]);
        }
 
        cout<<endl;
    }
    return 0;
}