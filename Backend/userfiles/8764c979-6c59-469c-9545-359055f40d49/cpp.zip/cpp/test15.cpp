#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<set>
#include<cmath>
using namespace std;

vector<string> strs;
vector<int> ncr;

int check(vector<int> hash[], set<int> noi, int n){
	int diff = 0;

	set<int>::iterator it1;
	for(it1 = noi.begin();it1!=noi.end();it1++){
		while(!hash[*it1].empty()){

			string f = strs[*(--(hash[*it1]).end())];
			// cout<<"f : "<<f<<endl;
			// cout<<"noi : "<<*it1<<endl;
			// // cout<<"hash : "<<hash[*it1]<<endl;
			// cout<<"hash : "<<*(--(hash[*it1].end()))<<endl;

			for(int i = 0;i<hash[*it1].size()-1;i++){
				
				string g = strs[hash[*it1][i]];
				// cout<<"g _ "<<g<<endl;
				
				bool go = false;
				int first = 0;


				for(int j = 0;j<n+1;j++){

					string stf = f.substr(first,ncr[j]);
					string stg = g.substr(first,ncr[j]);
					go = false;
					
					// cout<<"stf : "<<stf<<endl;

					for(int k = 0;k<ncr[j];k++){
						if(go)
							break;
						// cout<<"stg : "<<stg<<endl;

						if(stf == stg){
							// cout<<" done"<<endl;
							go = true;
						}
						next_permutation(stg.begin(), stg.end());
					}

					if(!go)
						break;

					first += ncr[j];
				}

				if(go){
					// cout<<"strs : "<<strs[*(hash[*it1].begin()+i)]<<endl;
					// cout<<"confirmed : "<<endl;
					// cout<<"g : "<<g<<endl;
					hash[*it1].erase(hash[*it1].begin()+i);
					diff--;
				}
			}
			
			hash[*it1].erase(--hash[*it1].end());
		}
	}

	return diff;
}

int main(){

	int n,m;
	cin>>n>>m;
	string str;

	for(int i = 0;i<m;i++){
		cin>>str;
		strs.push_back(str);
	}

	vector<int> hash[int(pow(2,n))+1];
	set<int> noi;

	for(int i = 0;i<m;i++){
		int ct = count(strs[i].begin(), strs[i].end(), '1');
		hash[ct].push_back(i);
		noi.insert(ct);
	}

	ncr.push_back(1);
	for(int i = 1;i<n+1;i++){
		ncr.push_back(ncr[i-1]*(n-i+1)/i);
	}

	// set<int>::iterator it;
	// for(it = noi.begin();it!=noi.end();it++){
	// 	cout<<*it<<" : "<<endl;
	// 	for(int j = 0;j<hash[*it].size();j++){
	// 		cout<<hash[*it][j]<<endl;
	// 	}
	// }

	int ans = check(hash,noi,n);
	// cout<<ans<<endl;
	cout<<m + ans<<endl;

}