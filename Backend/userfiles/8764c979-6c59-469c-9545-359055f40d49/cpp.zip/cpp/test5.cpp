#include <cstdio>
//#include <vector>
 
using namespace std;
 
int results[300000];
int positions[300000][2];
 
int main() {
    int t;
    scanf("%d", &t);
    int n, first, last, temp;
    while (t--) {
        scanf("%d", &n);
        //vector <vector <int> > pos(n);
        for (int i = 0; i < n; i++) {
            positions[i][0] = -1;
        }
        for (int i = 0; i < n; i++) {
            results[i] = 1;
            scanf("%d", &temp);
            if (positions[temp-1][0] == -1) {
                positions[temp-1][0] = i;
            }
            positions[temp-1][1] = i;
            //pos[i].push_back(i);
        }
 
        first = -1;
        last = n;
        for (int i = 0; i < n; i++) {
            if (positions[i][0] == -1) {
                for (int j = i; j < n; j++) {
                    results[n - 1 - j] = 0;
                }
                break;
            }
            else {
                //results[n - 1 - i] = 1;
                if (positions[i][0] == first + 1) {
                    first++;
                    if (positions[i][1] > positions[i][0]) {
                        for (int j = i; j < n; j++) {
                            results[n - 2 - j] = 0;
                        }
                        break;
                    }
                }
                else if (positions[i][1] == last - 1) {
                    last--;
                    if (positions[i][0] < positions[i][1]) {
                        for (int j = i; j < n; j++) {
                            results[n - 2 - j] = 0;
                        }
                        break;
                    }
                }
                else {
                    for (int j = i + 1; j < n-1; j++) {
                        results[n - 1 - j] = 0;
                    }
                    //break;
                }
            }
        }
 
        for (int i = 0; i < n; i++) {
            printf("%d", results[i]);
        }
 
        printf("\n");
    }
    return 0;
}