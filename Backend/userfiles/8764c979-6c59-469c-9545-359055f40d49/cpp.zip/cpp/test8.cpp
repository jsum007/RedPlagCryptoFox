#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

class permutation{
	int arr_len;
	vector<int> array;
public:
	

	permutation(){};

	permutation(int n,int a[]){
	
		arr_len = n;
		for(int i=0;i<n;i++){
			array.push_back(a[i]);
		}
	}
	~permutation(){};
	
	permutation(permutation const &q){
		
		arr_len = q.arr_len;
		array = q.array;
	}

	permutation const operator=(permutation const &q){
 		
 		permutation temp;
		temp.arr_len = q.arr_len;
		temp.array = q.array;
		return temp;

	}

	int size() const{
		return arr_len;
	}

	int* to_array() const{
		int *p;
		p = new int[arr_len];
		for(int i = 0;i<arr_len;i++){
			p[i] = array[i];
		}
		return p;
	}

	permutation const operator-() const{
		
		permutation inverse;
		inverse.arr_len = this->size();
		for(int i = 0;i<arr_len;i++){
			for(int j = 0;j<arr_len;j++){
				if(this->array[j]==i){
					inverse.array.push_back(j);
					break;
				}
			}
		}
		return inverse;
	}

	permutation const operator*(permutation const &q) const{

		permutation comp;
		comp.arr_len = this->size();
		for(int i = 0;i<arr_len;i++){
			comp.array.push_back(this->array[this->array[i]]);
		}
		return comp;
	}

	bool const operator==(permutation const &q) const{

		permutation rhs(q);
		permutation lhs(*this);
		return(lhs.array == rhs.array);

	}

	permutation const operator^(long long int i) const{

		permutation p(*this);
		permutation s(*this);

		for(int i = 0;i<p.size();i++)
			p = p*s;
		return p;

	}	

	bool is_power(permutation const &q) const{
		
		bool value = true;
		
		permutation p(*this);
		permutation s(q);
		permutation r(q);
		while(true){
			if(p == s)
				break;
			else{
				s = s*r;
				if(s == r){
					value = false;
					break;
				}

			}

		}

		return value;
	}	


	int log(permutation const &q) const{
		
		int value = 0;
		long long int count = 0;

		permutation p(*this);
		permutation s(q);
		permutation r(q);
		
		while(true){
			value = value%(1000000007) + 1;
			// count++;
			if(p == s){
				break;
			}
			else{
				s = s*r;
				if(s == r){
					value = 0;
					break;
				}

			}

		}

		return value;

	}

};

int main()
{
    int n;
    cin >> n;
    int a;
    vector < int >  v;
    vector<int> ans(n, 0);
    for (int i=0; i < n; i++)
    {
        cin >> a;
        v.push_back(a);
    }
    int d = 0;
    sort(v.begin(), v.end());
    for (int i = 1; i < n; i+=2)
    {
        ans[i] = v[(i - 1) / 2];
        d++;
    }
    for (int j = 0; j < n; j+=2)
    {
        ans[j] = v[d];
        d++;
    }
    if (n % 2 == 0) cout << n / 2 - 1<<endl;
    else cout << n / 2<<endl;
    for (int i=0; i < n; i++)
    {
        cout << ans[i]<<" ";
    }
    return 0;
}