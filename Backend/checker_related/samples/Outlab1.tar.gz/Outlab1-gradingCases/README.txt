We are providing the test cases we have used to grade your work. (For Tasks 2 and 3, the test case provided with the problem statement was one of the cases for grading)

Task 1 is simple, you can verify the correctness of your code with your own test cases.

For Task 2, see if your script also runs for https://www.cse.iitb.ac.in/~vahanwala/CS251/babington/another_letter.txt 

For Task 3, see if your script also runs for https://www.cse.iitb.ac.in/~vahanwala/hidden-verifier/ (you should supply the cut-dirs argument as 1). These are identical test cases for the same program we provided, just the names of input and output files are changed. 0 becomes 'sun', 1 becomes 'mercury', ..., 9 becomes 'pluto'. Is Pluto a planet? Doesn't matter, I ran out of names.

For Task 4, test0 is small, you can manually verify correctness. test1 is very similar to the one we provided, with a small difference. As an aside, if you're into grunge, do check out the indie band Blakc. (COAD = Choking on a Dream). If your code is correct, you should get a factually correct organisation. test1 isn't too big, you can see manually if you like. Important: the link target is a *relative* path, we even drew a diagram in the problem statement. 

We have provided big test cases for Task 5. The starting key is 0 for both, we have also provided the output textfiles. Be careful if you crib for this! We graded your work against never_gonna and lorem_ipsum, but if you crib, lorem_ipsum will be replaced by the tougher new_lorem. The starting key is "ZJtKEh" (without quotes)