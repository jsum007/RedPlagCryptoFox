from ring import *
import argparse


def series(k,x,n,s):
  val=RingInt(n,x)
  
  if s>3:
    return 'UNDEFINED'
  if s==1:
    if (n<=k):
      return 'UNDEFINED'
    sum_1=RingInt(n,0)
    for i in range(0,k):
      num_temp= val**i
      deno_temp= RingInt(n,modfac(i,n))
      try:
        temp1=num_temp/deno_temp
      except:
        return 'UNDEFINED'
      sum_1+=temp1      
    return sum_1

  if s==2:
    if (n<x+k):
      return 'UNDEFINED'
    res_final=RingInt(n,1)
    for i in range(0,k):
      sum_ini=RingInt(n,0)
      num_temp=RingInt(n,modfac(x+i,n))
      for j in range(0,i+1):
        deno_temp= RingInt(n,modfac(j,n))*RingInt(n,modfac(x+i-j,n))
        try:
          temp1=num_temp/deno_temp                   
        except:
          return 'UNDEFINED'
        sum_ini+=temp1 
      res_final*=sum_ini

    return res_final
  
  if s==3:
    if (n<=k or n<=x):
      return 'UNDEFINED'
    sum_i=RingInt(n,0)
    for i in range(1,k+1):
      temp=RingInt(n,modexp(i,x,n))
      sum_i+=temp
    return sum_i


parser=argparse.ArgumentParser()
parser.add_argument("-inp", action="store", dest="in_file")
parser.add_argument("-out", action="store", dest="out_file")
args = parser.parse_args()

infile_path=args.in_file
outfile_path=args.out_file

with open(infile_path, 'r') as file:
  data = file.readlines()


for l in data:
  k,x,n,s =(int(val) for val in l.split())
  output = series(k,x,n,s)
  with open(outfile_path, 'a+') as file_out:
    file_out.seek(0)
    temp = file_out.read()
    if len(temp) > 0 :
      file_out.write("\n")
    file_out.write(str(output))

