from ring import *
import argparse
import re


def check_msg(a_val, b_val, m):
	for cases in range(0, len(a_values)):
		sum_a=0
		sum_b=0
		for i, val1 in enumerate(a_values[cases],1):
			sum_a+=((i*int(val1))%n)
		if sum_a%n !=0:
			return 'CORRUPTED'

		for i, val1 in enumerate(b_values[cases],1):
			sum_b+=((i*int(val1))%n)
		if sum_b%n !=0:
			return 'CORRUPTED'
	return 'OK'




parser=argparse.ArgumentParser()
parser.add_argument("-m", action="store", dest="in_file")
args = parser.parse_args()


infile_path=args.in_file
with open(infile_path, 'r') as file:
	N=[int(x) for x in next(file).split()]
n=N[0]

with open(infile_path, 'r') as file:
	msg= file.read()
pattern = re.compile(r'\$\(([0-9]+,)*[0-9]+\)#\(([0-9]+,)*[0-9]+\)\$')
test_string = r'{}'.format(msg)

codes=[]
result = pattern.finditer(test_string)
if result:
  #print("Search successful.")
  for r in result:
  	temp=test_string[r.span()[0]:r.span()[1]]
  	codes.append(temp)
  	
else:
  print('OK')	
#print(codes)

#print([int(s) for s in temp.split() if s.isdigit()])
p_sub1=re.compile(r'\$\((.*)\)#')
p_sub2=re.compile(r'#\((.*)\)\$')



a_codes=[]
for a_t in codes:
	temp_a=p_sub1.finditer(a_t)
	for aaa in temp_a:
		temp=a_t[aaa.span()[0]:aaa.span()[1]]
		a_codes.append(temp)


a_values=[]
for code in a_codes:
	a_values.append(re.findall(r'\d+', code))


b_codes=[]
for b_t in codes:
	temp_b=p_sub2.finditer(b_t)
	for bbb in temp_b:
		temp=b_t[bbb.span()[0]:bbb.span()[1]]
		b_codes.append(temp)


b_values=[]
for code in b_codes:
	b_values.append(re.findall(r'\d+', code))



print(check_msg(a_values,b_values,n))