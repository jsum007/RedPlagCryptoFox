def gcd(a,b):
	if b==0:
		return a
	if a>=b:
		return gcd(b,a%b)
	if b>a:
		return gcd(b,a)
  
def modinv(a):
	x=a.modval
	m=a.charc

	if(gcd(m,x)!=1):
		raise ValueError('Undefined')

	for i in range(1,m):
		if (x*i)%m==1:
			return RingInt(m,i)

def modfac(a,m):
  if a<0:
  	raise ValueError('FActorial not defined for negative values')
  if a==0:
    return 1
  val=1
  for i in range(1,a+1):
    temp=i%m
    val=val*temp
  return val%m

def modexp(i,x,n):
  final=1
  if i==0 and x<0:
  	raise ValueError('0^(-neg) Undefined')
  if i==0:
    return 0
  if x==0:
    return 1  
  i= i%n
  while(x>0):
    if((x&1)==1):
      final = (final*i)%n
    x= x>>1
    i = (i*i)%n
  
  return final


class RingInt:
  def __init__(self, charc, value):
    self.charc=charc
    self.value=value
    self.modval=self.value % self.charc
    
  def __str__(self):
    return '{self.modval}[{self.charc}]'.format(self=self)
  
  def __eq__(self, x):
    if (x.charc==self.charc):
      if self.modval == x.modval:
        return True
      else:
        return False
    else:
      raise ValueError('Only defined when the characteristics of the operands are equal!')
  
  def __add__(self, x):
    if (x.charc==self.charc):
      m=(self.modval + x.modval)%self.charc
      return RingInt(self.charc,m)
    else:
      raise ValueError('Only defined when the characteristics of the operands are equal!')
  def __sub__(self, x):
    if (x.charc==self.charc):
      m=(self.modval - x.modval)%self.charc
      return RingInt(self.charc,m)
    else:
      raise ValueError('Only defined when the characteristics of the operands are equal!')

  def __mul__(self, x):
    if (x.charc==self.charc):
      m=(self.modval*x.modval)%self.charc
      return RingInt(self.charc,m)
    else:
      raise ValueError('Only defined when the characteristics of the operands are equal!')

  def __pow__(self, x):
  	if(self.modval !=0 and x<0):
  		return modinv(self)**(-x)  		
  	if(self.modval==0 and x<0):
  		raise ValueError(' 0^(-neg) is not defined!')
  	m=(self.modval**x)%self.charc
  	return RingInt(self.charc,m)

  def __truediv__(self,x):
    if self==x:
      return RingInt(self.charc,1) 
    if (x.charc==self.charc and x.modval!=0 and gcd(x.charc,x.modval)==1):
      m=(self.modval*modinv(x).modval)%self.charc
      return RingInt(self.charc,m)
    if (x.charc!= self.charc):
      raise ValueError('Only defined when the characteristics of the operands are equal!')
    if (x.modval==0):
      raise ValueError('Cannot divide by 0, as its multiplicative inverse doesnt exist')
    if gcd(x.charc,x.modval) !=1:
      raise ValueError('Cannot divide by {}, as multiplicative inverse doesnt exist for it'.format(x))








