class PowTwo:
    """Class to implement an iterator
    of powers of two"""

    def __init__(self, max=0):
        self.max = max

    def __iter__(self):
        self.n = 0
        return self

    def __next__(self):
        if self.n <= self.max:
            result = 2 ** self.n
            self.n += 1
            return result
        else:
            raise StopIteration


# create an object
numbers = PowTwo(3)
print(numbers)

# create an iterable from the object
e = iter(numbers)

for i in PowTwo(3):
    print(i)

# Using next to get to the next iterator element

print(next(e))
print(next(e))
print(next(e))
print(next(e))
#print(next(i))